# Student isolation (Stage 5 §I Step 2): how to read the results

`results/decision.json` holds the screen outcome. A target PASSES when its test
greedy cost beats the matched-time REINFORCE control with a paired 95% interval
below zero AND it keeps at least `min_retention` of the teacher's gain over
Stage 1 greedy (retention = (Stage 1 - student) / (Stage 1 - teacher)).
CONTINUE names the passing target with the best validation cost; run the
`confirm` profile next (seeds 1 and 2: new training graphs, same val/test).
STOP means one round of search distillation did not beat more REINFORCE at the
same wall time for any target.

`results/policies.csv` lists every policy on the test graphs (and on the
canonical 10K seed-42 set when enabled). `fix_rate` is the share of the
teacher's corrections to Stage 1 (steps where the MCTS action differs from the
Stage 1 argmax, along the teacher's test trajectories) that the policy now
makes; `keep_rate` is its agreement with the teacher elsewhere. Read the two
together: correction steps are near-ties for Stage 1 (it puts ~0.23 on the
teacher's move there), so any perturbed policy flips some of them; a real
absorption raises fix_rate while keeping keep_rate near 1. Students and the
control were selected on the validation graphs, never on test; validation
numbers are therefore optimistic, test numbers are not.

Limits: one fixed teacher and one round of distillation; the iterated loop can
compound gains this test does not see. Wall times are Colab-runtime specific.
Intervals are per seed; check that seeds agree before claiming anything.
