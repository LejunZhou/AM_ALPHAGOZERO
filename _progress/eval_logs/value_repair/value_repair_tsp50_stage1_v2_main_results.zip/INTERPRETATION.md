# Value evaluator diagnostic: interpretation

Primary contrasts: repaired vs original_wide (information vs capacity) and
repaired_geo vs repaired (does explicit tour geometry help beyond endpoints?)
on held-out sibling regret and search cost. original_wide approximately matches
the repaired head's parameter count; repaired_geo has 14 extra inputs (about
1.8K more parameters at d=128) and predicts a residual over the MST bound, so
the `mst` control is its zero-MLP baseline. original is the unchanged small
architecture refitted on the same data. checkpoint_head is an historical
reference with a different training history.

All refits use identical raw greedy-policy completion targets, state-balanced
MSE, fixed train-instance feature statistics, optimizer settings, and seeded
minibatch orders. Best checkpoints are selected by validation rollout-target
MSE; test sibling/search results never select weights. Exact DP is an evaluation
oracle, not a training target. Features and targets are cached; the policy and
its normalization buffers remain frozen.

Read sibling_summary.csv by state source and remaining horizon. exact_states
is the denominator for exact regret/accuracy: horizons above the configured DP
cap have no certified ranking result. rollout_target_errors.csv measures a
different quantity: prediction of the frozen completion policy.

paired_contrasts.csv averages paired decision differences within each graph
before computing an approximate 95% interval across graphs. Negative differences
favor the repaired head. Intervals are conditional on a head seed and frozen
checkpoint; they do not describe variation across training seeds. Inspect all
seeds and their sample standard deviation in the notebook.

Search uses the Python reference implementation. prior_only assigns a constant
total estimate at nonterminal leaves while still backing up exact terminal
costs. mst uses an admissible geometric remaining-cost bound. Both retain the
same policy prior and search machinery. equal_K is a simulation-budget control.
calibrated_time picks K on separate instances to approximate rollout search's
time at the configured K. This is not a strict deadline; inspect actual test
seconds and time_ratio_to_target before claiming time-matched superiority.
Times include a measured greedy normalizer pass plus encoding/search, exclude
model loading and data transfer to the search device, and are hardware/backend
specific. Refitted feature construction is included. Resumed runs can span
sessions; rerun search in a fresh output directory for publication timings.

Before proceeding: check validation curves for unfinished fitting, all head
seeds, the parameter-count control, off-policy and early-horizon decisions,
and the actual quality/time tradeoff. Improvement only at short tails does not
establish an early-search solution. Successful evaluator repair would justify
a separate short policy-distillation experiment; it does not establish that
self-play will beat the REINFORCE baseline.
